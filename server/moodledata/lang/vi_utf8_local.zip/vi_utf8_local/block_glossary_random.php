<?PHP // $Id$ 
      // block_glossary_random.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['addentry'] = 'Đưa thêm trích dẫn mà bạn yêu thích!';
$string['askaddentry'] = 'Khi thành viên có thể viết thêm các thuật ngữ mới, hiển thị đường liên kết tới văn bản này';
$string['askinvisible'] = 'Khi thành viên không thể viết thêm các thuật ngữ mới, hiển thị văn bản này (không có đường liên kết)';
$string['askviewglossary'] = 'Khi thành viên có thể xem nhưng không thể thêm thuật ngữ mới, hiển thị đường liên kết tới văn bản này';
$string['blockname'] = 'Thuật ngữ ngẫu nhiên';
$string['intro'] = 'Hãy chắc rằng bạn có ít nhất một bảng thuật ngữ với ít nhất một thuật ngữ để đưa vào khoá học này. Rồi bạn sẽ có thể thay đổi các thiết lập tiếp theo';
$string['lastmodified'] = 'Thuật ngữ mới sửa';
$string['nextone'] = 'Thuật ngữ tiếp theo';
$string['noentriesyet'] = 'Không có thuật ngữ nào trong bảng thuật ngữ đã chọn.';
$string['notyetconfigured'] = 'Hãy nhấn lên biểu tượng chỉnh sửa để cấu hình khối này.';
$string['notyetglossary'] = 'Bạn cần có ít nhất một bảng thuật ngữ để chọn.';
$string['random'] = 'Thuật ngữ ngẫu nhiên';
$string['refresh'] = 'Ngày trước khi chọn một thuật ngữ mới';
$string['select_glossary'] = 'Lấy các thuật ngữ từ bảng thuật ngữ này';
$string['showconcept'] = 'Hiển thị khái niệm (tựa) cho mỗi thuật ngữ';
$string['title'] = 'Tựa';
$string['type'] = 'Cách chọn một thuật ngữ mới';
$string['viewglossary'] = 'Nhiều trích dẫn hơn...';
$string['whichfooter'] = 'Bạn có thể cho hiển thị các đường liên kết tới các hành động có liên quan đến khối này. Khối sẽ chỉ hiển thị các đường liên kết tới những hành động được mở cho bảng thuật ngữ trên.';

?>
