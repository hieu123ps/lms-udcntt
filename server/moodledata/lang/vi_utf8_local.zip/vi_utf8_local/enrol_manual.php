<?PHP // $Id$ 
      // enrol_manual.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['description'] = 'Đây là mẫu ghi danh mặc định của hệ thống. Có hai cách chính để cho phép học viên ghi danh vào một khoá học.
<ul>
<li>Giáo viên hoặc quản trị viên ghi danh họ bằng cách mở đường liên kết trong trình đơn Quản trị khoá học.</li>
<li>Khoá học có thể có một ô khai báo mật khẩu, gọi là \"mật khẩu ghi danh\". Bất cứ ai cũng có thể tự ghi danh vào khoá học khi có mật khẩu này.';
$string['enrolname'] = 'Ghi danh nội bộ';
$string['keyholderrole'] = 'Vai trò của học viên có mật khẩu ghi danh vào một khoá học. Hiển thị khi có học viên muốn ghi danh vào khoá học đó.';

?>
