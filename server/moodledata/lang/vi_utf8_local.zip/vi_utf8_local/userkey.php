<?PHP // $Id$ 
      // userkey.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['createnewkey'] = 'Tạo chìa khoá thành viên mới';
$string['createuserkey'] = 'Tạo chìa khoá thành viên';
$string['deletekeyconfirm'] = 'Bạn có chắc chắn muốn xoá chìa khoá thành viên này?';
$string['edituserkey'] = 'Sửa chìa khoá thành viên';
$string['keyiprestriction'] = 'Hạn chế IP chìa khoá';
$string['keymanager'] = 'Quản lí chìa khoá';
$string['keyvaliduntil'] = 'Chìa khoá có hiệu lực đến';
$string['keyvalue'] = 'Giá trị chìa khoá';
$string['newuserkey'] = 'Chìa khoá thành viên mới';
$string['userkey'] = 'Chìa khoá thành viên';
$string['userkeys'] = 'Chìa khoá thành viên';

?>
