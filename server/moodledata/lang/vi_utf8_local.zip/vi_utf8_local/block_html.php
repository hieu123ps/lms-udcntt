<?PHP // $Id$ 
      // block_html.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['configtitle'] = 'Tên khối';
$string['leaveblanktohide'] = 'Chừa trống để giấu tên khối';

?>
