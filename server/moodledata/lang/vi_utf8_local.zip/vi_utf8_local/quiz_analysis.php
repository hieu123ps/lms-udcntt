<?PHP // $Id$ 
      // quiz_analysis.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['analysis'] = 'Phân tích theo yếu tố';
$string['analysisdownload'] = 'Tải bản phân tích xuống';
$string['analysisoptions'] = 'Tuỳ chọn phân tích';
$string['analysistitle'] = 'Bảng phân tích theo yếu tố';
$string['attemptsall'] = 'tất cả các lượt';
$string['attemptselection'] = 'Số lượt làm bài phân tích theo mỗi thành viên';
$string['attemptsfirst'] = 'lượt đầu tiên';
$string['attemptshighest'] = 'lượt có điểm cao nhất';
$string['attemptslast'] = 'lượt cuối cùng';
$string['dicsindextitle'] = 'Chỉ số<br />phân biệt';
$string['disccoefftitle'] = 'Hệ số<br />phân biệt';
$string['downloadooo'] = 'Tải về theo định dạng OpenOffice';
$string['facilitytitle'] = 'Chỉ số<br />độ dễ';
$string['lowmarkslimit'] = 'Không phân tích nếu điểm thấp hơn';
$string['pagesize'] = 'Số câu hỏi mỗi trang:';
$string['qcounttitle'] = 'Số câu hỏi';
$string['qidtitle'] = 'Q#';
$string['qnametitle'] = 'Tên câu hỏi';
$string['qtexttitle'] = 'Nội dung câu hỏi';
$string['qtypetitle'] = 'Kiểu câu hỏi';
$string['quizreportdir'] = 'trac-nghiem_bao-cao';
$string['rcounttitle'] = 'Số<br />câu đúng';
$string['reportanalysis'] = 'Báo cáo phân tích theo yếu tố';
$string['responsestitle'] = 'Nội dung phương án trả lời';
$string['rfractiontitle'] = 'Điểm<br />từng phần';
$string['rpercenttitle'] = 'Tỉ lệ<br />đúng';
$string['stddevtitle'] = 'Độ<br />lệch chuẩn';

?>
