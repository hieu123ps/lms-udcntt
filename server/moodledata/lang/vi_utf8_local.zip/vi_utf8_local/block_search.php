<?PHP // $Id$ 
      // block_search.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['blockname'] = 'Tìm kiếm tổng thể';
$string['bytes'] = 'byte (để 0 nếu không muốn giới hạn)';
$string['configbuttonlabel'] = 'Nhãn của nút';
$string['configenablefileindexing'] = 'Mở chức năng lập chỉ mục các tập tin';
$string['configfiletypes'] = 'Định dạng tập tin';
$string['configlimitindexbody'] = 'Giới hạn dung lượng phần lập chỉ mục';
$string['configpdftotextcmd'] = 'Đường dẫn tới lệnh pdftotext';
$string['configsearchtext'] = 'Tìm văn bản';
$string['configwordtotextcmd'] = 'Đường dẫn tới lệnh doctotext';
$string['configwordtotextenv'] = 'Thiết lập môi trường cho bộ chuyển đổi MSWord';
$string['go'] = 'Tìm!';
$string['searchmoodle'] = 'Tìm trong toàn hệ thống';
$string['usemoodleroot'] = 'Dùng thư mục gốc Moodle đối với các bộ chuyển đổi bên ngoài';

?>
