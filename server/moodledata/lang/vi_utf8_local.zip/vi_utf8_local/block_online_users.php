<?PHP // $Id$ 
      // block_online_users.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['blockname'] = 'Thành viên đang trực tuyến';
$string['configtimetosee'] = 'Khoảng thời gian (phút) để xem như thành viên không còn trực tuyến nếu không có hoạt động gì';
$string['periodnminutes'] = 'cách đây $a phút';
$string['timetosee'] = 'Thời gian rút tên (phút) nếu không có hoạt động gì';

?>
