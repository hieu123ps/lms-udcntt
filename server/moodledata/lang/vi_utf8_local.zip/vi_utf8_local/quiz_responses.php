<?PHP // $Id$ 
      // quiz_responses.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['pagesize'] = 'Số lượt làm bài trong mỗi trang:';
$string['reportresponses'] = 'Câu trả lời chi tiết';
$string['responses'] = 'Câu trả lời chi tiết';
$string['responsesoptions'] = 'Tuỳ chọn trả lời';
$string['responsestitle'] = 'Câu trả lời chi tiết';

?>
