<?PHP // $Id$ 
      // filters.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['actfilterhdr'] = 'Bộ lọc hoạt động';
$string['addfilter'] = 'Thêm bộ lọc';
$string['anycategory'] = 'Bất cứ chuyên mục nào';
$string['anycourse'] = 'Bất cứ khoá học nào';
$string['anyfield'] = 'Bất cứ mục thông tin nào';
$string['anyrole'] = 'Bất cứ vai trò nào';
$string['anyvalue'] = 'Bất cứ giá trị nào';
$string['categoryrole'] = 'Vai trò trong chuyên mục';
$string['contains'] = 'có chứa';
$string['courserole'] = 'Vai trò trong khoá học';
$string['courserolelabel'] = '$a->label là $a->rolename trong $a->coursename thuộc $a->categoryname';
$string['courserolelabelerror'] = '$a->label error: không có khoá học $a->coursename';
$string['datelabelisafter'] = '$a->label diễn ra sau $a->after';
$string['datelabelisbefore'] = '$a->label diễn ra trước $a->before';
$string['datelabelisbetween'] = '$a->label diễn ra giữa $a->after và $a->before';
$string['doesnotcontain'] = 'không chứa';
$string['endswith'] = 'kết thúc bằng';
$string['firstaccess'] = 'Truy cập lần đầu';
$string['globalrolelabel'] = '$a->label là $a->value';
$string['isafter'] = 'sau ngày';
$string['isanyvalue'] = 'có bất cứ giá trị nào';
$string['isbefore'] = 'trước ngày';
$string['isdefined'] = 'được định nghĩa';
$string['isempty'] = 'rỗng';
$string['isequalto'] = 'bằng với';
$string['isnotdefined'] = 'không được định nghĩa';
$string['isnotequalto'] = 'khác với';
$string['newfilter'] = 'Bộ lọc mới';
$string['profilelabel'] = '$a->label: $a->profile $a->operator $a->value';
$string['profilelabelnovalue'] = '$a->label: $a->profile $a->operator';
$string['removeall'] = 'Xoá tất cả các bộ lọc';
$string['removeselected'] = 'Xoá phần được chọn';
$string['selectlabel'] = '$a->label $a->operator $a->value';
$string['startswith'] = 'bắt đầu bằng';
$string['tablenosave'] = 'Các thay đổi trong bảng trên đây có hiệu lực ngay lập tức.';
$string['textlabel'] = '$a->label $a->operator $a->value';
$string['textlabelnovalue'] = '$a->label $a->operator';

?>
