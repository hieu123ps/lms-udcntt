<?PHP // $Id$ 
      // qtype_match.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addmoreqblanks'] = 'Thêm {no} cặp ô trống nữa';
$string['nomatchinganswerforq'] = 'Bạn phải nêu phương án trả lời cho câu hỏi này.';
$string['notenoughquestions'] = 'Bạn phải đưa ra ít nhất $a cặp câu hỏi và phương án trả lời.';

?>
