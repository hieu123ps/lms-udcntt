<?PHP // $Id$ 
      // group.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['defaultgrouping'] = 'Tổ mặc định';
$string['defaultgroupingname'] = 'Tổ';
$string['defaultgroupname'] = 'Nhóm';
$string['enrolmentkey'] = 'Mật khẩu ghi danh';
$string['group'] = 'Nhóm';
$string['groupdescription'] = 'Mô tả nhóm';
$string['grouping'] = 'Tổ';
$string['groupingdescription'] = 'Mô tả tổ';
$string['groupingname'] = 'Tên tổ';
$string['groupings'] = 'Tổ';
$string['groupingsonly'] = 'Chỉ theo tổ';
$string['groupmember'] = 'Thành viên nhóm';
$string['groupmembers'] = 'Thành viên nhóm';
$string['groupmemberssee'] = 'Thấy thành viên cùng nhóm';
$string['groupmode'] = 'Phân nhóm';
$string['groupmodeforce'] = 'Bắt buộc phân nhóm';
$string['groupmy'] = 'Nhóm của tôi';
$string['groupname'] = 'Tên nhóm';
$string['groups'] = 'Nhóm';
$string['groupscount'] = 'Nhóm ($a)';
$string['groupsgroupings'] = 'Nhóm &amp; tổ';
$string['groupsinselectedgrouping'] = 'Nhóm trong:';
$string['groupsnone'] = 'Không phân nhóm';
$string['groupsonly'] = 'Chỉ theo nhóm';
$string['groupspreview'] = 'Xem thử nhóm';
$string['groupsseparate'] = 'Nhóm riêng biệt';
$string['groupsvisible'] = 'Nhóm thấy nhau được';
$string['grouptemplate'] = 'Nhóm @';
$string['members'] = 'Số thành viên mỗi nhóm';
$string['membersofselectedgroup'] = 'Thành viên của:';
$string['numgroups'] = 'Số nhóm';
$string['nummembers'] = 'Số thành viên mỗi nhóm';
$string['overview'] = 'Tổng quan';
$string['potentialmembers'] = 'Số thành viên tiềm năng: $a';
$string['printerfriendly'] = 'Mở dạng trang in';
$string['random'] = 'Ngẫu nhiên';
$string['removegroupfromselectedgrouping'] = 'Rút nhóm ra khỏi tổ';
$string['removegroupingsmembers'] = 'Rút tất cả các nhóm ra khỏi tổ';
$string['removegroupsmembers'] = 'Rút tất cả các thành viên ra khỏi nhóm';
$string['removeselectedusers'] = 'Rút tên thành viên được chọn';
$string['selectfromrole'] = 'Chọn thành viên theo vai trò';
$string['showgroupsingrouping'] = 'Hiển thị nhóm trong tổ';
$string['showmembersforgroup'] = 'Hiển thị thành viên trong nhóm';

?>
