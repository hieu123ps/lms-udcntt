<?PHP // $Id$ 
      // qtype_shortanswer.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addmoreanswerblanks'] = 'Thêm {no} ô trống';
$string['answerno'] = 'Phương án $a';
$string['filloutoneanswer'] = 'Bạn cần phải đưa ra ít nhất một phương án trả lời đúng. Những ô để trống sẽ không được sử dụng. Phương án trả lời đúng đầu tiên sẽ được dùng để tính điểm và đưa ra nhận xét phản hồi.';

?>
