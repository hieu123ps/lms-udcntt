<?PHP // $Id$ 
      // qtype_randomsamatch.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['nosaincategory'] = 'Không có câu hỏi trả lời ngắn nào trong mục \'$a->catname\' mà bạn đã chọn. Hãy chọn một mục khác và soạn vài câu hỏi trong đó.';
$string['notenoughsaincategory'] = 'Chỉ có $a->nosaquestions câu hỏi trả lời ngắn trong mục \'$a->catname\' mà bạn đã chọn. Hãy chọn một mục khác và soạn vài câu hỏi trong đó, hay giảm bớt số câu hỏi mà bạn đã chọn.';

?>
