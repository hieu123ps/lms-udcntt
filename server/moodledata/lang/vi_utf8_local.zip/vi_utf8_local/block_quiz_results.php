<?PHP // $Id$ 
      // block_quiz_results.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['bestgrade'] = 'Điểm số cao nhất:';
$string['bestgrades'] = '$a điểm số cao nhất:';
$string['bestgroupgrade'] = 'Nhóm có điểm bình quân cao nhất:';
$string['bestgroupgrades'] = '$a nhóm có điểm bình quân cao nhất:';
$string['config_format_absolute'] = 'Số tuyệt đối';
$string['config_format_fraction'] = 'Phân đoạn';
$string['config_format_percentage'] = 'Tỉ lệ phần trăm';
$string['config_grade_format'] = 'Hiển thị điểm theo:';
$string['config_name_format'] = 'Mức độ tin cậy của kết quả hiển thị:';
$string['config_names_anon'] = 'Kết quả khuyết danh';
$string['config_names_full'] = 'Hiển thị tên đầy đủ';
$string['config_names_id'] = 'Chỉ hiển thị số hiệu';
$string['config_no_quizzes_in_course'] = 'Khoá học này không có hoạt động làm bài tập kiểm tra nào. Bạn cần phải đưa vào ít nhất một bài thì mới có thể khai thác khối này một cách hợp lí.';
$string['config_select_quiz'] = 'Bạn muốn hiển thị kết quả của bài tập trắc nghiệm nào trong khối này?';
$string['config_show_best'] = 'Cần hiển thị bao nhiêu điểm số cao nhất (để 0 nếu muốn tắt)?';
$string['config_show_worst'] = 'Cần hiển thị bao nhiêu điểm số thấp nhất (để 0 nếu muốn tắt)?';
$string['config_use_groups'] = 'Hiển thị nhóm thay cho các học viên (chỉ khi nào bài tập trắc nghiệm được phân theo nhóm)?';
$string['configuredtoshownothing'] = 'Cấu hình của khối này hiện không cho phép hiển thị được kết quả. Hãy sửa lại cấu hình hoặc tắt đi.';
$string['error_emptyquizid'] = 'Hiện đang có lỗi xảy ra ở khối này: bạn cần phải chọn một bài tập trắc nghiệm để xem được kết quả.';
$string['error_emptyquizrecord'] = 'Hiện đang có lỗi xảy ra ở khối này: bài tập trắc nghiệm được chọn có lẽ không tồn tại trong cơ sở dữ liệu.';
$string['error_nogroupsexist'] = 'Hiện đang có lỗi xảy ra ở khối này: cần hiển thị theo nhóm, nhưng khoá học không có phân nhóm.';
$string['formaltitle'] = 'Kết quả bài tập trắc nghiệm';
$string['worstgrade'] = 'Điểm số thấp nhất:';
$string['worstgrades'] = '$ điểm số thấp nhất:';
$string['worstgroupgrade'] = 'Nhóm có điểm bình quân thấp nhất:';
$string['worstgroupgrades'] = '$ nhóm có điểm bình quân thấp nhất:';

?>
