<?PHP // $Id$ 
      // countries.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['AE'] = 'Các Tiểu Vương quốc Arab Thống nhất';
$string['AQ'] = 'Châu Nam Cực';
$string['AU'] = 'Australia';
$string['AX'] = 'Quần đảo Åland';
$string['BE'] = 'Bỉ';
$string['BL'] = 'Saint Barthélemy';
$string['CD'] = 'Cộng hoà Dân chủ Congo';
$string['CF'] = 'Cộng hoà Trung Phi';
$string['CI'] = 'Bờ Biển Ngà';
$string['CK'] = 'Quần đảo Cook';
$string['CX'] = 'Đảo Giáng sinh';
$string['CZ'] = 'Cộng hoà Séc';
$string['DO'] = 'Cộng hoà Dominican';
$string['EH'] = 'Tây Sahara';
$string['FI'] = 'Phần Lan';
$string['FK'] = 'Qunầ đảo Falkland (Malvinas)';
$string['FM'] = 'Liên bang Micronesia';
$string['FO'] = 'Quần đảo Faroe';
$string['GF'] = 'Guiana Pháp';
$string['GG'] = 'Guernsey';
$string['GQ'] = 'Guinea Xích đạo';
$string['GR'] = 'Hi Lạp';
$string['GS'] = 'Nam Georgia và Quần đảo South Sandwich';
$string['HK'] = 'Hồng Kông';
$string['HM'] = 'Quầ đảo Heard và Mc Donald';
$string['IE'] = 'Ireland';
$string['IM'] = 'Isle Of Man';
$string['IS'] = 'Iceland';
$string['IT'] = 'Italia';
$string['JE'] = 'Jersey';
$string['JP'] = 'Nhật Bản';
$string['KH'] = 'Campuchia';
$string['KP'] = 'Cộng hoà Dân chủ Nhân dân Triều Tiên';
$string['KW'] = 'Kuwait';
$string['KY'] = 'Quần đảo Cayman';
$string['LA'] = 'Lào';
$string['MD'] = 'Cộng hoà Moldova';
$string['ME'] = 'Montenegro';
$string['MF'] = 'Saint Martin';
$string['MH'] = 'Quần đảo Marshall';
$string['MP'] = 'Quần đảo Northern Mariana';
$string['NC'] = 'Tân Caledonia';
$string['PT'] = 'Bồ Đào Nha';
$string['RS'] = 'Serbia';
$string['SA'] = 'Saudi Arabia';
$string['SB'] = 'Quần đảo Solomon';
$string['SE'] = 'Thuỵ Điển';
$string['TH'] = 'Thái Lan';
$string['TL'] = 'Đông Timor';
$string['TR'] = 'Thổ Nhĩ Kì';
$string['UM'] = 'United States Minor Outlying Islands';
$string['US'] = 'Hoa Kì';

?>
