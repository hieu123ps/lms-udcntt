<?PHP // $Id$ 
      // my.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['mymoodle'] = 'Tổng quan các khoá học của tôi';
$string['nocourses'] = 'Không có thông tin nào cả.';
$string['noguest'] = 'Khách vãng lai không xem được trang \"Tổng quan khoá học\".';
$string['pinblocks'] = 'Cấu hình khối cô định cho Moodle của tôi';
$string['pinblocksexplan'] = 'Mọi người sẽ xem được (và không chỉnh sửa được) các khối mà bạn lập ở đây, thông qua trang \"Tổng quan các khoá học\" của họ.';

?>
