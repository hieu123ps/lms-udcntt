<?PHP // $Id$ 
      // pix.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['approve'] = 'Duyệt';
$string['blackeye'] = 'Bầm mắt';
$string['blush'] = 'Đỏ mặt';
$string['clown'] = 'Chú hề';
$string['cool'] = 'Quá đã';
$string['evil'] = 'Ác quỉ';
$string['mixed'] = 'Phân vân';
$string['wideeyes'] = 'Tròn mắt';
$string['wink'] = 'Đá lông nheo';

?>
