<?PHP // $Id$ 
      // lesson.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['accesscontrol'] = 'Kiểm soát truy cập';
$string['actions'] = 'Hành động';
$string['activitylink'] = 'Liên kết đến một hoạt động';
$string['activitylinkname'] = 'Chuyển đến: $a';
$string['addanendofbranch'] = 'Thêm một điểm kết nhánh';
$string['addaquestionpagehere'] = 'Thêm một trang câu hỏi ở đây';
$string['addcluster'] = 'Thêm một cụm';
$string['addedabranchtable'] = 'Đã thêm một bảng phân nhánh';
$string['addedanendofbranch'] = 'Đã thêm một điểm kết nhánh';
$string['addedaquestionpage'] = 'Đã thêm một trang câu hỏi';
$string['addedcluster'] = 'Đã thêm một cụm';
$string['addedendofcluster'] = 'Đã thêm một điểm kết cụm';
$string['addendofcluster'] = 'Thêm một điểm kết cụm';
$string['addpage'] = 'Thêm một trang';
$string['anchortitle'] = 'Bắt đầu nội dung chính';
$string['and'] = 'AND';

?>
