<?PHP // $Id$ 
      // block_mentees.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['blockname'] = 'Kèm riêng';
$string['configtitle'] = 'Tên khối';
$string['leaveblanktohide'] = 'Chừa trống để ẩn tựa đề';
$string['newmenteesblock'] = '(khối \"Kèm riêng\" mới)';

?>
