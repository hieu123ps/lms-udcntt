<?PHP // $Id$ 
      // form.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['addfields'] = 'Thêm $a trường vào mẫu';
$string['advancedelement'] = 'Yếu tố nâng cao';
$string['day'] = 'Ngày';
$string['display'] = 'Hiển thị';
$string['err_alphanumeric'] = 'Bạn chỉ được nhập chữ hoặc số vào đây.';
$string['err_email'] = 'Bạn phải nhập vào một địa chỉ điện thư hợp lệ';
$string['err_lettersonly'] = 'Bạn chỉ được nhập chữ vào đây.';
$string['err_maxlength'] = 'Bạn không được nhập hơn $a->format kí tự vào đây.';
$string['err_minlength'] = 'Bạn phải nhập ít nhất $a->format kí tự vào đây.';
$string['err_nonzero'] = 'Bạn phải nhập vào đây một số không bắt đầu bằng 0.';
$string['err_nopunctuation'] = 'Bạn không được nhập dấu câu vào đây.';
$string['err_numeric'] = 'Bạn phải nhập một chữ số vào đây.';
$string['err_rangelength'] = 'Bạn phải nhập từ {$a->format[0]} đến {$a->format[1]} kí tự vào đây.';
$string['err_required'] = 'Bạn phải nhập thông tin vào đây.';
$string['general'] = 'Thông tin chung';
$string['hideadvanced'] = 'Ẩn các yếu tố nâng cao';
$string['hour'] = 'Giờ';
$string['minute'] = 'Phút';
$string['miscellaneoussettings'] = 'Thiết lập phụ';
$string['modstandardels'] = 'Thiết lập chung cho module';
$string['month'] = 'Tháng';
$string['nomethodforaddinghelpbutton'] = 'Không có cách nào để thêm một nút trợ giúp vào yếu tố $a->name (lớp $a->classname) của mẫu';
$string['nonexistentformelements'] = 'Thử thêm nút trợ giúp vào yếu tố không có sẵn của mẫu: $a';
$string['optional'] = 'Tuỳ ý';
$string['othersettings'] = 'Thiết lập khác';
$string['requiredelement'] = 'Thông tin bắt buộc';
$string['revealpassword'] = 'Tiết lộ';
$string['security'] = 'Bảo mật';
$string['selectallornone'] = 'Chọn tất cả/Không chọn gì';
$string['showadvanced'] = 'Hiển thị các yếu tố nâng cao';
$string['somefieldsrequired'] = 'Có các mục thông tin bắt buộc, được đánh dấu $a';
$string['timing'] = 'Thời gian';
$string['unmaskpassword'] = 'Cho thấy mật khẩu';
$string['year'] = 'Năm';

?>
