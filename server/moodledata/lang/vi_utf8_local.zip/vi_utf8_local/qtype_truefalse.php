<?PHP // $Id$ 
      // qtype_truefalse.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addingtruefalse'] = 'Thêm câu hỏi Đúng/Sai';
$string['correctanswer'] = 'Phương án trả lời đúng';
$string['editingtruefalse'] = 'Biên soạn câu hỏi Đúng/Sai';
$string['false'] = 'Sai';
$string['feedbackfalse'] = 'Phản hồi cho phương án \"Sai\".';
$string['feedbacktrue'] = 'Phản hồi cho phương án \"Đúng\".';
$string['true'] = 'Đúng';
$string['truefalse'] = 'Câu hỏi Đúng/Sai';

?>
