<?PHP // $Id$ 
      // mimetypes.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['application/msword'] = 'tài liệu Word';
$string['application/pdf'] = 'tài liệu PDF';
$string['application/vnd.ms-excel'] = 'bảng tính Excel';
$string['application/vnd.ms-powerpoint'] = 'trình chiếu PowerPoint';
$string['application/zip'] = 'lưu trữ zip';
$string['audio/mp3'] = 'tập tin âm thanh MP3';
$string['audio/wav'] = 'tập tin âm thanh';
$string['document/unknown'] = 'tập tin';
$string['image/bmp'] = 'hình ảnh BMP (không nén)';
$string['image/gif'] = 'hình ảnh GIF';
$string['image/jpeg'] = 'hình ảnh JPEG';
$string['text/plain'] = 'tập tin văn vản thô';
$string['text/rtf'] = 'tài liệu RTF';

?>
