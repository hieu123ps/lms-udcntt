<?PHP // $Id$ 
      // block_tag_flickr.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['blockname'] = 'Flickr';
$string['configtitle'] = 'Tựa';
$string['date-posted-asc'] = 'Ngày đăng tăng dần';
$string['date-posted-desc'] = 'Ngày đăng giảm dần';
$string['date-taken-asc'] = 'Ngày chụp tăng dần';
$string['date-taken-desc'] = 'Ngày chụp giảm dần';
$string['defaulttile'] = 'Flickr';
$string['getfromphotoset'] = 'Lấy hình ảnh từ bộ ảnh có số hiệu';
$string['includerelatedtags'] = 'Gộp cả thẻ từ khoá trong truy vấn tìm kiếm';
$string['interestingness-asc'] = 'Độ ưa thích tăng dần';
$string['interestingness-desc'] = 'Độ ưa thích giảm dần';
$string['numberofphotos'] = 'Số ảnh';
$string['relevance'] = 'Độ thích hợp';
$string['sortby'] = 'Sắp xếp theo';

?>
