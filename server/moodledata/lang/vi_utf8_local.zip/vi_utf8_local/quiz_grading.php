<?PHP // $Id$ 
      // quiz_grading.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['essayonly'] = 'Những câu hỏi sau đây cần chấm điểm thủ công';
$string['gradeall'] = 'Chấm điểm toàn bộ $a lượt làm bài';
$string['graded'] = '(đã chấm)';
$string['gradenextungraded'] = 'Chấm $a lượt làm bài chưa có điểm tiếp theo';
$string['gradeungraded'] = 'Chấm toàn bộ $a lượt làm bài chưa có điểm';
$string['grading'] = 'Chấm điểm thủ công';
$string['gradingall'] = 'Toàn bộ $a lượt làm bài trong câu hỏi này';
$string['gradingattempt'] = 'Lượt làm bài thứ $a->attempt của $a->fullname.';
$string['gradingnextungraded'] = '$a lượt làm bài chưa có điểm tiếp theo';
$string['gradingnotallowed'] = 'Bạn không có quyền chấm điểm thủ công trong bài kiểm tra này.';
$string['gradingungraded'] = '$a lượt làm bài chưa có điểm';
$string['gradinguser'] = 'Lượt làm bài của $a';
$string['questiontitle'] = 'Câu hỏi $a->number: \"$a->name\" ({$a->openspan}$a->gradedattempts{$a->closespan} / $a->totalattempts lượt làm bài {$a->openspan}đã chấm{$a->closespan}).';

?>
