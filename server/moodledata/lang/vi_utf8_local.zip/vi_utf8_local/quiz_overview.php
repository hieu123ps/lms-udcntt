<?PHP // $Id$ 
      // quiz_overview.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['allattempts'] = 'Xem tất cả các lượt làm bài';
$string['allattemptscontributetograde'] = 'Tất cả các lượt làm bài đều tính vào điểm cuối cùng.';
$string['allstudents'] = 'Xem toàn bộ $a';
$string['attemptsonly'] = 'Chỉ xem $a đã làm bài';
$string['attemptsprepage'] = 'Số lượt làm bài trong mỗi trang';
$string['deleteselected'] = 'Xoá lượt làm bài được chọn';
$string['highlightinggraded'] = 'Lượt làm bài có tính vào điểm cuối cùng đã được bôi sáng';
$string['noattemptsonly'] = 'Chỉ xem/tải $a chưa làm bài';
$string['onlyoneattemptallowed'] = 'Mỗi người chỉ được làm bài một lần trong bài kiểm tra này.';
$string['optallattempts'] = 'tất cả các lượt làm bài';
$string['optallstudents'] = 'toàn bộ \"$a\"';
$string['optattemptsonly'] = 'chỉ \"$a\" đã làm bài';
$string['optnoattemptsonly'] = 'chỉ \"$a\" chưa làm bài';
$string['optonlygradedattempts'] = 'chỉ lượt làm bài được chấm điểm cho mỗi $a';
$string['overview'] = 'Điểm số';
$string['overviewdownload'] = 'Tải bảng điểm';
$string['overviewreportgraph'] = 'Biểu đồ phân bố điểm số';
$string['pagesize'] = 'Cỡ trang';
$string['preferencespage'] = 'Thiết lập cho trang này';
$string['preferencessave'] = 'Lưu thiết lập';
$string['preferencesuser'] = 'Thiết lập cho báo cáo của bạn';
$string['show'] = 'Xem/Tải về';
$string['showdetailedmarks'] = 'Xem/Tải điểm cho mỗi câu hỏi';
$string['showinggraded'] = 'Chỉ xem lượt làm bài có chấm điểm của mỗi thành viên.';
$string['showinggradedandungraded'] = 'Xem tất cả các lượt làm bài của mỗi thành viên. Những lượt làm bài có chấm điểm được bôi sáng. Bài kiểm tra này được chấm điểm theo phương pháp $a.';

?>
