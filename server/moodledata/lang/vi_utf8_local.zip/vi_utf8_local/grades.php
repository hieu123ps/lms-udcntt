<?PHP // $Id$ 
      // grades.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['gradecategories'] = 'Mục điểm số';
$string['gradecategory'] = 'Mục điểm số';
$string['gradecategorysettings'] = 'Thiết lập mục điểm số';
$string['grades'] = 'Điểm số';
$string['gradessettings'] = 'Thiết lập điểm số';
$string['gradeview'] = 'Xem điểm';
$string['uncategorised'] = 'Không phân chuyên mục';

?>
