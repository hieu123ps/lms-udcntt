<?PHP // $Id$ 
      // block_course_list.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['adminview'] = 'Xem với tư cách quản trị';
$string['allcourses'] = 'Quản trị viên thấy được tất cả các khoá học';
$string['blockname'] = 'Danh sách khoá học';
$string['configadminview'] = 'Cấu hình hiển thị khối danh sách khoá học đối với quản trị viên';
$string['confighideallcourseslink'] = 'Ẩn liên kết \"Tất cả các khoá học\" bên dưới khối. Thiết lập này không có hiệu lực đối với quản trị viên';
$string['hideallcourseslink'] = 'Ẩn liên kết \"Tất cả các khoá học\"';
$string['owncourses'] = 'Quản trị viên chỉ thấy được các khoá học của mình';

?>
