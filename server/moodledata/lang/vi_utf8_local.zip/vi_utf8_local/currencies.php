<?PHP // $Id$ 
      // currencies.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['CNY'] = 'Nhân dân tệ';
$string['VND'] = 'đồng Việt Nam';

?>
