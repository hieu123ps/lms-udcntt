<?PHP // $Id$ 
      // mediaplugin.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['filtername'] = 'Plugin đa phương tiện';
$string['flashanimation'] = 'Ảnh động flash';
$string['flashvideo'] = 'Video flash';
$string['mp3audio'] = 'Âm thanh MP3';

?>
