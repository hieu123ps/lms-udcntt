<?PHP // $Id$ 
      // qtype_multichoice.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addingmultichoice'] = 'Thêm câu hỏi nhiều lựa chọn';
$string['addmorechoiceblanks'] = 'Thêm {no} ô trống';
$string['answerhowmany'] = 'Một hay nhiều phương án đúng?';
$string['answernumbering'] = 'Số phương án trả lời?';
$string['answernumbering123'] = '1., 2., 3., ...';
$string['answernumberingABCD'] = 'A., B., C., ...';
$string['answernumberingabc'] = 'a., b., c., ...';
$string['answernumberingnone'] = 'Không đánh số';
$string['answersingleno'] = 'Cho phép chọn nhiều phương án trả lời';
$string['answersingleyes'] = 'Chỉ có một phương án đúng';
$string['choiceno'] = 'Phương án $a';
$string['choices'] = 'Các phương án lựa chọn';
$string['clozeaid'] = 'Điền từ còn thiếu vào ô trống';
$string['correctfeedback'] = 'Với mọi câu trả lời đúng';
$string['editingmultichoice'] = 'Biên soạn câu hỏi nhiều lựa chọn';
$string['errfractionsaddwrong'] = 'Tổng các mức điểm bạn chọn chưa đạt 100%%.<br />Hiện chỉ mới được $a%%.';
$string['errfractionsnomax'] = 'Nên có một phương án đạt 100%%, nhờ đó<br />có thể đạt được điểm tối đa cho câu hỏi này.';
$string['feedback'] = 'Phản hồi';
$string['fillouttwochoices'] = 'Bạn phải đưa ra ít nhất hai phương án trả lời. Những ô để trống sẽ không được sử dụng.';
$string['fractionsaddwrong'] = 'Tổng mức điểm bạn chọn chưa đạt 100%%.<br />Hiện chỉ mới được $a%%.<br />Bạn có muốn quay lại để sửa lỗi này?';
$string['fractionsnomax'] = 'Nên có một phương án đạt 100%%, nhờ đó<br />có thể đạt được điểm tối đa cho câu hỏi này.<br />Bạn có muốn quay lại để sửa lỗi này?';
$string['incorrectfeedback'] = 'Với mọi câu trả lời sai';
$string['notenoughanswers'] = 'Kiểu câu hỏi này cần có ít nhất $a phương án trả lời';
$string['overallcorrectfeedback'] = 'Phản hồi cho mọi câu trả lời đúng';
$string['overallfeedback'] = 'Phản hồi chung';
$string['overallincorrectfeedback'] = 'Phản hồi cho mọi câu trả lời sai';
$string['overallpartiallycorrectfeedback'] = 'Phản hồi cho mọi câu trả lời đúng một phần';
$string['partiallycorrectfeedback'] = 'Với mọi câu trả lời đúng một phần';
$string['shuffleanswers'] = 'Xáo trộn các phương án trả lời?';
$string['singleanswer'] = 'Chọn một phương án trả lời.';

?>
