<?PHP // $Id$ 
      // block_tag_youtube.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['anycategory'] = 'Mọi chuyên mục';
$string['autosvehicles'] = 'Xe cộ';
$string['blockname'] = 'Youtube';
$string['category'] = 'Chuyên mục';
$string['comedy'] = 'Hài hước';
$string['configtitle'] = 'Tựa';
$string['entertainment'] = 'Giải trí';
$string['filmsanimation'] = 'Phim ảnh &amp; Hoạt hình';
$string['gadgetsgames'] = 'Trò chơi điện tử';
$string['howtodiy'] = 'Tháo vát &amp; Mẹo vặt';
$string['includeonlyvideosfromplaylist'] = 'Chỉ gộp video từ danh sách có số hiệu';
$string['music'] = 'Âm nhạc';
$string['newspolitics'] = 'Tin tức &amp; Thời sự';
$string['numberofvideos'] = 'Số video';
$string['peopleblogs'] = 'Cá nhân &amp; Blog';
$string['petsanimals'] = 'Loài vật';
$string['sports'] = 'Thể thao';
$string['travel'] = 'Du lịch &amp; Cảnh quan';

?>
