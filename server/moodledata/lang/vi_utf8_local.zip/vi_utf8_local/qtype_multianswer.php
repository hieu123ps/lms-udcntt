<?PHP // $Id$ 
      // qtype_multianswer.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['correctanswer'] = 'Phương án trả lời đúng';
$string['correctanswerandfeedback'] = 'Phương án trả lời đúng và phản hồi';
$string['decodeverifyquestiontext'] = 'Giải mã và kiểm tra nội dung câu hỏi';
$string['nooptionsforsubquestion'] = 'Không thể mở tuỳ chọn của phần số $a->sub của câu hỏi (question->id={$a->id})';
$string['noquestions'] = 'Câu hỏi Cloze (nhiều phương án trả lời) \"<strong>$a</strong>\" không có câu hỏi nao.';
$string['qtypenotrecognized'] = 'Không nhận diện được kiểu câu hỏi $a';
$string['questionnotfound'] = 'Không thể tìm thấy phần số $a của câu hỏi';
$string['questionsmissing'] = 'Không có câu hỏi hợp lệ. Hãy tạo ra ít nhất một câu hỏi.';
$string['unknownquestiontypeofsubquestion'] = 'Kiểu câu hỏi không nhận diện được: $a->type trong phần số $a->sub của câu hỏi.';

?>
