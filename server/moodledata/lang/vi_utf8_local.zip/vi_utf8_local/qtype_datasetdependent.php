<?PHP // $Id$ 
      // qtype_datasetdependent.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['additem'] = 'Thêm yếu tố';
$string['atleastonerealdataset'] = 'Cần có ít nhất một bộ dữ liệu thật trong nội dung câu hỏi';
$string['atleastonewildcard'] = 'Cần có ít nhất một kí tự thay thế trong công thức trả lời hoặc trong nội dung câu hỏi';
$string['calcdistribution'] = 'Phân phối';
$string['calclength'] = 'Chữ số thập phân';
$string['calcmax'] = 'Tối đa';
$string['calcmin'] = 'Tối thiểu';
$string['dataitemdefined'] = 'với $a giá trị số đã được định nghĩa sẵn sàng';
$string['datasetrole'] = 'Kí tự thay thế <strong>{x..}</strong> sẽ được thay bằng một giá trị số trong bộ dữ liệu tương ứng.';
$string['deletelastitem'] = 'Xoá yếu tố cuối cùng';
$string['existingcategory1'] = 'một kí tự trong một bộ kí tự có sẵn đã được sử dụng trong các câu hỏi khác của mục này';
$string['existingcategory2'] = 'một tập tin trong một nhóm tập tin đã được sử dụng trong các câu hỏi khác của mục này';
$string['existingcategory3'] = 'một liên kết trong một nhóm liên kết đã được sử dụng trong các câu hỏi khác của mục này';
$string['forceregeneration'] = 'Bắt buộc cập nhật';
$string['getnextnow'] = 'Lấy \"Yếu tố cần thêm\" ngay bây giờ';
$string['item(s)'] = 'yếu tố';
$string['itemno'] = 'Yếu tố $a';
$string['itemscount'] = 'Yếu tố<br />Số lượng';
$string['itemtoadd'] = 'Yếu tố cần thêm';
$string['keptcategory1'] = 'một kí tự trong một bộ kí tự tái sử dụng được thuộc cùng mục như trước';
$string['keptcategory2'] = 'một tập tin trong nột nhóm tập tin tái sử dụng được thuộc cùng mục như trước';
$string['keptcategory3'] = 'một liên kết trong một nhóm liên kết tái sử dụng được thuộc cùng mục như trước';
$string['keptlocal1'] = 'một kí tự trong một bộ kí tự riêng trong cùng câu hỏi như trước';
$string['keptlocal2'] = 'một tập tin trong một nhóm tập tin riêng trong cùng câu hỏi như trước';
$string['keptlocal3'] = 'một liên kết trong một nhóm liên kết riêng trong cùng câu hỏi như trước';
$string['lastitem(s)'] = 'yếu tố cuối cùng';
$string['loguniform'] = 'Đồng dạng log';
$string['minmax'] = 'Dãy giá trị';
$string['newcategory1'] = 'một kí tự trong một bộ kí tự mới có thể dùng trong câu hỏi khác thuộc cùng mục này';
$string['newcategory2'] = 'một tập tin trong một nhóm tập tin mới có thể dùng trong câu hỏi khác thuộc cùng mục này';
$string['newcategory3'] = 'một liên kết trong một nhóm liên kết mới có thể dùng trong câu hỏi khác thuộc cùng mục này';
$string['newlocal1'] = 'một kí tự trong một bộ kí tự mới chỉ sử dụng trong câu hỏi này';
$string['newlocal2'] = 'một tập tin trong một nhóm tập tin mới chỉ sử dụng trong câu hỏi này';
$string['newlocal3'] = 'một liên kết trong một nhóm liên kết mới  chỉ sử dụng trong câu hỏi này';
$string['nodataset'] = 'không gì cả - đây không phải là kí tự thay thế';
$string['param'] = 'Thông số {<strong>$a</strong>}';
$string['replacewithrandom'] = 'Thay thế bằng một giá trị ngâu nhiên';
$string['reuseifpossible'] = 'dùng lại giá trị trước nếu có';
$string['sharedwildcard'] = 'Kí tự thay thế dùng chung';
$string['sharedwildcards'] = 'Kí tự thay thế dùng chung';
$string['uniform'] = 'Đồng dạng';
$string['updatedatasetparam'] = 'Cập nhật thông số bộ dữ liệu';
$string['youmustaddatleastoneitem'] = 'Bạn cần phải thêm ít nhất một yếu tố vào bộ dữ liệu trước khi lưu câu hỏi.';

?>
