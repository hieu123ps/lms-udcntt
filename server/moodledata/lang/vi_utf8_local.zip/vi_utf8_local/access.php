<?PHP // $Id$ 
      // access.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['accesshelp'] = 'Trợ giúp về khả năng truy cập';
$string['accesskey'] = 'Phím tắt, $a';
$string['activitynext'] = 'Hoạt động tiếp theo';
$string['breadcrumb'] = 'Vị trí lướt duyệt';
$string['currenttopic'] = 'Chủ đề này';
$string['currentweek'] = 'Tuần này';
$string['hideblocka'] = 'Ẩn khối $a';
$string['monthnext'] = 'Tháng sau';
$string['showblocka'] = 'Mở khối $a';
$string['sitemap'] = 'Sơ đồ trang';
$string['skipnavigation'] = 'Bỏ qua thanh lướt duyệt';
$string['tablelayout'] = 'Định dạng bảng, $a';
$string['tocontent'] = 'Chuyển sang nội dung chính';
$string['tonavigation'] = 'Chuyển tới thanh lướt duyệt';

?>
