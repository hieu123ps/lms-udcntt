<?PHP // $Id$ 
      // block_mnet_hosts.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['mnet_hosts'] = 'Máy chủ mạng lưới';
$string['server'] = 'Máy chủ';

?>
