<?PHP // $Id$ 
      // qtype_numerical.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addmoreanswerblanks'] = 'Thêm {no} ô trống cho phương án trả lời';
$string['addmoreunitblanks'] = 'Thêm {no} ô trống cho đơn vị';
$string['answermustbenumberorstar'] = 'Câu trả lời cần phải có dạng số, hoặc \'*\'';
$string['answerno'] = 'Phương án $a';
$string['errornomultiplier'] = 'Bạn cần phải cho biết số nhân của đơn vị này.';
$string['errorrepeatedunit'] = 'Bạn không thể dùng hai đơn vị trùng tên.';
$string['notenoughanswers'] = 'Bạn phải cho biết ít nhất một phương án trả lời';
$string['unithdr'] = 'Đơn vị $a';

?>
