<?PHP // $Id$ 
      // notes.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addnewnote'] = 'Thêm ghi chú mới';
$string['addnewnoteselect'] = 'Chọn thành viên để viết ghi chú';
$string['bynameondate'] = 'của $a->name - $a->date';
$string['content'] = 'Nội dung';
$string['course'] = 'khoá học';
$string['coursenotes'] = 'Ghi chú về khoá học';
$string['created'] = 'tạo';
$string['deleteconfirm'] = 'Xoá ghi chú này?';
$string['deletenotes'] = 'Xoá mọi ghi chú';
$string['editnote'] = 'Sửa ghi chú';
$string['groupaddnewnote'] = 'Thêm ghi chú chung';
$string['nocontent'] = 'Không thể để trống nội dung ghi chú.';
$string['nonotes'] = 'Hiện chưa có ghi chú loại này.';
$string['note'] = 'Ghi chú';
$string['notes'] = 'Ghi chú';
$string['notesnotvisible'] = 'Bạn không được phép xem ghi chú.';
$string['nouser'] = 'Bạn cần phải chọn một thành viên';
$string['personal'] = 'cá nhân';
$string['personalnotes'] = 'Ghi chú cá nhân';
$string['publishstate'] = 'Trạng thái';
$string['site'] = 'hệ thống';
$string['sitenotes'] = 'Ghi chú về hệ thống';
$string['unknown'] = 'không biết';

?>
