<?PHP // $Id$ 
      // qtype_calculated.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['addmoreanswerblanks'] = 'Thêm ô trống mới';
$string['addmoreunitblanks'] = 'Ô trống cho $a đơn vị nữa';
$string['answerhdr'] = 'Phương án trả lời';
$string['atleastoneanswer'] = 'Bạn cần đưa ra ít nhất một phương án trả lời.';
$string['correctanswershows'] = 'Câu trả lời đúng hiển thị';
$string['correctanswershowsformat'] = 'Định dạng';
$string['existingcategory1'] = 'sẽ dùng một bộ dữ liệu chung có sẵn';
$string['keptcategory1'] = 'sẽ dùng cùng bộ dữ liệu chung như trước';
$string['keptlocal1'] = 'sẽ dùng cùng bộ dữ liệu riêng như trước';
$string['makecopynextpage'] = 'Trang sau (câu hỏi mới)';
$string['mandatoryhdr'] = 'Bắt buộc có kí tự thay thế bên trong câu trả lời';
$string['mustbenumeric'] = 'Bạn phải nhập vào đây một con số';
$string['mustnotbenumeric'] = 'Ở đây không thể dùng số.';
$string['newcategory1'] = 'sẽ dùng một bộ dữ liệu chung mới';
$string['newlocal1'] = 'sẽ dùng một bộ dữ liệu riêng mới';
$string['nextitemtoadd'] = '\"Yếu tố cần thêm\" tiếp theo';
$string['nextpage'] = 'Trang sau';
$string['nodataset'] = 'không gì cả - đây không phải là kí tự thay thế';
$string['nosharedwildcard'] = 'Không có kí tự thay thế chung nào';
$string['possiblehdr'] = 'Kí tự thay thế có thể chỉ có mặt trong nội dung câu hỏi';
$string['tolerance'] = 'Dung sai &plusmn;';
$string['trueanswerinsidelimits'] = 'Phương án đúng: $a->correct bên trong giới hạn giá trị thật $a->true';
$string['trueansweroutsidelimits'] = '<span class=\"error\">LỖI Phương án đúng: $a->correct bên ngoài giới hạn giá trị thật $a->true</span>';
$string['updatecategory'] = 'Cập nhật mục câu hỏi';
$string['usedinquestion'] = 'Được dùng trong câu hỏi';
$string['youmustenteramultiplierhere'] = 'Bạn phải nhập số nhân vào đây.';

?>
