<?PHP // $Id$ 
      // block_section_links.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['blockname'] = 'Đường liên kết tới các phần';
$string['topics'] = 'Chủ đề';
$string['weeks'] = 'Tuần';

?>
