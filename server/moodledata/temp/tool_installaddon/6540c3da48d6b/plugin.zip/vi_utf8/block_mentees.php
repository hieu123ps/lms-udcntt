<?PHP // $Id$ 
      // block_mentees.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['blockname'] = 'Kèm riêng';
$string['configtitle'] = 'Tên khối';
$string['leaveblanktohide'] = 'Để trống để ẩn tiêu đề';
$string['newmenteesblock'] = '(khối \"Kèm riêng\" mới)';

?>
