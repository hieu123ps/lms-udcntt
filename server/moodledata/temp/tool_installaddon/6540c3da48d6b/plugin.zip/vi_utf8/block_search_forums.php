<?php //$Id$

$string['blocktitle'] = 'Tìm kiếm các diễn đàn';
$string['advancedsearch'] = 'Tìm kiếm nâng cao';

?>