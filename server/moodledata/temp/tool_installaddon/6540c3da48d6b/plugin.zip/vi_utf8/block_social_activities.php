<?php // $Id$ 

$string['blockname'] = 'Các hoạt động mang tính xã hội';
?>
