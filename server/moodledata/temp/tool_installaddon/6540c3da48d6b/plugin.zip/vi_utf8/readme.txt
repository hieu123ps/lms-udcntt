﻿Vietnames language pack by  Thanh Hung <vthung@moet.edu.vn> and Dinh Lu Giang (dinh@lugiang.com) an


ENGLISH
-------

English là ngôn ngữ mặc định của Moodle, và gói ngôn ngữ này 
là chính để các gói khác có thể so sánh.

Nếu một chuỗi nào dó trong ngôn ngữ khác bị thiếu
thì phiên bản tiếng anh sẽ được sử dụng.

Mỗi môđun hoạt động cài đặt trong moodle/mod sẽ có một file ở đây 
,cũng như file chính mà được gọi là "moodle.php".

Thư mục "trợ giúp" chứa toàn bộ các trang được viết bằng HTML,
và thư mục "tài liệu" chứa toàn bộ các tài liệu hỗn hợp khác.

Nếu bạn đang suy nghĩ chuyển Moodle sang một ngôn ngữ khác,
Vui lòng liên lạc lại với Martin Dougiamas!

