<?php /// $Id$

$string['filtername'] = "Các chương trình bổ sung hỗ trợ đa phương tiện";

?>