<?PHP // $Id$ 
      // bulkusers.php - created with Moodle 1.9.2+ (Build: 20080827) (2007101522)
      // local modifications from http://localhost/online


$string['addall'] = 'Thêm tất cả';
$string['addsel'] = 'Thêm vào nhóm chọn';
$string['allfilteredusers'] = 'Toàn bộ số được lọc ($a->count/$a->total)';
$string['allselectedusers'] = 'Toàn bộ số được chọn ($a->count/$a->total)';
$string['allusers'] = 'Toàn bộ thành viên ($a)';
$string['available'] = 'Có hiệu lực';
$string['confirmmessage'] = 'Bạn có chắc chắn muốn gửi tin nhắn trên cho tất cả các thành viên này không?<br />$a';
$string['nofilteredusers'] = 'Thành viên không tìm thấy t(0/$a)';
$string['noselectedusers'] = 'Chưa có ai được chọn';
$string['removeall'] = 'Bỏ tất cả';
$string['removesel'] = 'Bỏ tất cả khỏi nhóm chọn';
$string['selected'] = 'Được chọn';
$string['selectedlist'] = 'Danh sách thành viên được chọn';
$string['usersfound'] = 'Tìm thấy $a thành viên';
$string['usersinlist'] = 'Thành viên trong danh sách';
$string['usersselected'] = '$a thành viên được chọn.';

?>
