<?PHP // $Id$ 
      // block_html.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['configtitle'] = 'Tên khối';
$string['leaveblanktohide'] = 'Để trống để giấu tên khối';

?>
