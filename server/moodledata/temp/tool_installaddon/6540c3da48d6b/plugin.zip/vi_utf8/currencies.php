<?PHP // $Id$ 
      // currencies.php - created with Moodle 1.9.2+ (Build: 20080827) (2007101522)
      // local modifications from http://localhost/online


$string['CNY'] = 'Nhân dân tệ';
$string['JPY'] = 'đồng Yên';
$string['SUR'] = 'đồng Rúp Nga';
$string['THB'] = 'đồng Bạt Thái';
$string['USD'] = 'Đô la Mỹ';
$string['VND'] = 'đồng Việt Nam';

?>
