<?php /// $Id$

$string['filtername'] = "Chú thích văn bản";

?>