<?php // $Id$ 
      // error.php - created with Moodle 1.2 development (2003122600)

$string['coursegroupunknown'] = 'Cua học tương ứng với nhóm  $a không được chỉ ra';
$string['confirmsesskeybad'] = 'Xin lỗi bạn, nhưng khoá phiên của bạn không thể được xác nhận đối với việc thực hiện hành động này. Đặc trưng bảo mật này ngăn chặn lại việc thực hiện hiểm độc các chức năng quan trọng trong tên của bạn. Vui lòng đảm bảo rằng bạn thực sự muốn thực hiện chức năng này.';
$string['erroronline'] = 'Lỗi trên dòng $a';
$string['fieldrequired'] = '\"$a\" là một trường được yêu cầu';
$string['filenotfound'] = 'Xin lỗi, file yêu cầu không được tìm thấy';
$string['groupalready'] = 'Người dùng thuộc nhóm $a rồi';
$string['groupunknown'] = 'Nhóm $a không được cộng tác với cua học theo danh nghĩa';
$string['invalidfieldname'] = '\"$a\" không là một tên trường hợp lý';
$string['missingfield'] = 'Trường \"$a\" đang thiếu';
$string['modulerequirementsnotmet'] = 'Môđun \"$a->modulename\" ($a->moduleversion) không thể được cài đặt. Nó yêu cầu một phiên bản mới hơn của Moodle ( hiện hành bạn đang sử dụng $a->currentmoodle, bạn cần $a->requiremoodle).';
$string['notavailable'] = 'Điều này hiện hành không có sẵn';
$string['restricteduser'] = 'Xin lỗi bạn, nhưng tài khoản hiện hành của bạn \"$a\" bị hạn chế do đang sử dụng nó .';
$string['sessionipnomatch'] = 'Xin lỗi bạn, nhưng địa chỉ IP của bạn dường như thay đổi từ khi bạn đăng nhập lần đầu tiên. Đặc trưng bảo mật này ngăn cản các tội phạm máy tính ăn cắp tên đăng nhập và mật khẩu của bạn trong khi bạn đăng nhập vào site này. Bình thường những người dùng không nên được nhìn thấy thông báo này - Vui lòng yêu cầu nhà quản trị của site giúp.';
$string['unknowncourse'] = 'Không biết cua học gọi tên \"$a\"';
$string['usernotaddederror'] = 'Người dùng \"$a\" không được thêm - lỗi không biết';
$string['usernotaddedregistered'] = 'Người dùng \"$a\" không được thêm - được đăng ký rồi';
$string['usernotavailable'] = 'Thông tin chi tiết về người dùng này không có sẵn cho bạn.';

?>
