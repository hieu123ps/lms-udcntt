<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.

$string['auth_nntpdescription'] = 'Phương pháp này sử dụng một máy chủ NNTP để kiểm tra khi nào tên đăng nhập và mật khẩu đưa ra là hợp lệ.';
$string['auth_nntphost'] = 'Các địa chỉ máy chủ NNTP. Sử dụng địa chỉ IP, không sử dụng tên DNS.';
$string['auth_nntpport'] = 'Cổng máy chủ (119 là phổ biến nhất )';
$string['auth_nntptitle'] = 'Sử dụng một máy chủ NNTP';