<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.
