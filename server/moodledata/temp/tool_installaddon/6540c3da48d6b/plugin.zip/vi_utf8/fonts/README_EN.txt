This language may not be supported by lib/default.ttf,
you can find more information in lang/en_utf8/fonts/README.txt.

You can override the default font for this language 
by copying new font into this directory and renaming it
to default.ttf

Recommended fonts:
?
