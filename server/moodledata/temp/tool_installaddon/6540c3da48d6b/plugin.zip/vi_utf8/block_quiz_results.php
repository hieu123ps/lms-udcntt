<?PHP // $Id$ 
      // block_quiz_results.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['bestgrade'] = 'Điểm số cao nhất:';
$string['bestgrades'] = '$a điểm số cao nhất:';
$string['bestgroupgrade'] = 'Nhóm có điểm bình quân cao nhất:';
$string['bestgroupgrades'] = '$a nhóm có điểm bình quân cao nhất:';
$string['config_format_absolute'] = 'Số tuyệt đối';
$string['config_format_fraction'] = 'Phân đoạn';
$string['config_format_percentage'] = 'Tỉ lệ phần trăm';
$string['config_grade_format'] = 'Hiển thị điểm theo:';
$string['config_name_format'] = 'Mức độ tin cậy của kết quả hiển thị:';
$string['config_names_anon'] = 'Kết quả khuyết danh';
$string['config_names_full'] = 'Hiển thị tên đầy đủ';
$string['config_names_id'] = 'Chỉ hiển thị số hiệu';
$string['config_no_quizzes_in_course'] = 'Khoá học này không có hoạt động trắc nghiệm nào. Bạn cần phải đưa vào ít nhất một bài thì mới có thể sử dụng được khối này.';
$string['config_select_quiz'] = 'Bạn muốn hiển thị kết quả của bài tập trắc nghiệm nào trong khối này?';
$string['config_show_best'] = 'Cần hiển thị bao nhiêu điểm số cao nhất (để 0 nếu muốn tắt)?';
$string['config_show_worst'] = 'Cần hiển thị bao nhiêu điểm số thấp nhất (để 0 nếu muốn tắt)?';
$string['config_use_groups'] = 'Hiển thị nhóm học viên thay cho học viên (chỉ khi nào bài trắc nghiệm được phân theo nhóm)?';
$string['configuredtoshownothing'] = 'Cấu hình của khối này hiện không cho phép hiển thị kết quả. Hãy thay đổi lại cấu hình hoặc tắt nó đi.';
$string['error_emptyquizid'] = 'Hiện đang có lỗi ở khối này: bạn cần phải chọn một bài tập trắc nghiệm để xem kết quả.';
$string['error_emptyquizrecord'] = 'Hiện đang có lỗi ở khối này: bài trắc nghiệm được chọn có lẽ không tồn tại trong cơ sở dữ liệu.';
$string['error_nogroupsexist'] = 'Hiện đang có lỗi ở khối này: cần hiển thị theo nhóm, nhưng khoá học không có phân nhóm.';
$string['formaltitle'] = 'Kết quả bài trắc nghiệm';
$string['worstgrade'] = 'Điểm số thấp nhất:';
$string['worstgrades'] = '??? điểm số thấp nhất:';
$string['worstgroupgrade'] = 'Nhóm có điểm bình quân thấp nhất:';
$string['worstgroupgrades'] = '??? nhóm có điểm bình quân thấp nhất:';

?>
