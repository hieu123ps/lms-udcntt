Tài liệu về Moodle
--------------------

Nếu bạn muốn dịch tài liệu này sang một ngôn ngữ khác,
Tôi sẽ gợi ý với bạn rằng:

 1) Đừng chứa các file của phiên bản tiếng anh trong thư mục này 
    bởi vì chúng sẽ được tự động sử dụng ngay khi tìm thấy thiếu trong gói
    ngôn ngữ của bạn.

 2) Dịch chúng theo thứ sau (bắt đầu với những file quan trọng ):
  
    Những file quan trọng nhất
    |-------------------
    |
    |   - files.php
    |   - install.html
    |   - installamp.html
    |   - upgrade.html
    |   - faq.html
    |
    |  -----------------
    |
    |   - teacher.html
    |   - module_files.txt
    | 
    |  -----------------
    |   
    |   - intro.html
    |   - features.html
    |   - release.html
    |
    |  -----------------
    |
    |   - developer.html
    |   - cvs.html
    |   - future.html
    |
    |  -----------------
    |   
    |   - license.html
    |
    |-------------------
     Các file ít quan trọng

 3) đừng dịch file credits.html tất cả - nó thay đổi nhiều.


