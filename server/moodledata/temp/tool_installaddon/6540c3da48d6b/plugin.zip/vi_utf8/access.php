<?PHP // $Id: access.php,v 1.1 2006/12/06 12:58:37 vthung Exp $ 
      // access.php - created with Moodle 1.7 (2006101007)


$string['access'] = 'Khả năng truy cập';
$string['accesshelp'] = 'Trợ giúp khả năng truy cập';
$string['accesskey'] = 'Khóa truy cập, $a';
$string['accessstatement'] = 'Phát biểu khả năng truy cập';
$string['activitynext'] = 'Hoạt động tới';
$string['activityprev'] = 'Hoạt động trước';
$string['breadcrumb'] = 'Vệt mẩu bánh mì';
$string['monthnext'] = 'Tháng tới';
$string['monthprev'] = 'Tháng trước';
$string['showhideblock'] = 'Hiện, ẩn khối';
$string['sitemap'] = 'Bản đồ trang';
$string['skipa'] = 'Bỏ qua $a';
$string['skipblock'] = 'Bỏ qua khối';
$string['skipnavigation'] = 'Bỏ qua điều hướng';
$string['tabledata'] = 'Bảng dữ liệu, $a';
$string['tablelayout'] = 'Bảng biểu diễn, $a';
$string['tocontent'] = 'Tới nội dung chính';
$string['tonavigation'] = 'Tới điều hướng';
$string['youarehere'] = 'Bạn đang ở đây';

?>
