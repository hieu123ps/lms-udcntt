<?php /// $Id$

$string['filtername'] = " Nội dung đa ngôn ngữ ; ";

?>