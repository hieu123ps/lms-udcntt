<?php // $Id$

$string['responsesoptions'] = 'Các tuỳ chọn trả lời';
$string['responsestitle'] = 'Các câu trả lời chi tiết';
$string['pagesize'] = 'Các lần thử mỗi trang: ';
$string['reportresponses'] = 'Các câu trả lời chi tiết';
?>
