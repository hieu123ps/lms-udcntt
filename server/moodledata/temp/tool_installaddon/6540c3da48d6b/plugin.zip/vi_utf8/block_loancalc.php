<?PHP // $Id$ 
      // block_loancalc.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://localhost/moodle192


$string['amountofloan'] = 'Số tiền vay';
$string['fortnightly'] = 'Mỗi hai tháng';
$string['interestrate'] = 'Lãi suất';
$string['loancalc'] = 'Máy tính vay tiền';
$string['loanterm'] = 'Thời hạn vay';
$string['monthly'] = 'Hàng tháng';
$string['repaymentamount'] = 'Số tiền trả';
$string['repaymentfreq'] = 'Định kì trả';
$string['weekly'] = 'Hàng tuần';

?>
