<?php // $Id$ 
      // pix.php - created with Moodle 1.2 development (2003111400)


$string['angry'] = 'Tức giận';
$string['approve'] = 'Đồng ý';
$string['biggrin'] = 'Cười lớn';
$string['blackeye'] = 'Mắt bị đánh thâm tím';
$string['blush'] = 'Cái liếc mắt';
$string['clown'] = 'anh hề';
$string['cool'] = 'Thờ ơ';
$string['dead'] = 'Chết';
$string['evil'] = 'Thảm hoạ';
$string['kiss'] = 'Hôn';
$string['mixed'] = 'Hỗn hợp';
$string['sad'] = 'Buồn';
$string['shy'] = 'E thẹn';
$string['sleepy'] = 'Buồn ngủ';
$string['smiley'] = 'Mỉm cười';
$string['surprise'] = 'Ngạc nhiên';
$string['thoughtful'] = 'Trầm ngâm';
$string['tongueout'] = 'Thè lưỡi';
$string['wideeyes'] = 'các mắt mở to';
$string['wink'] = 'nháy';

?>
