<?php // $Id$ 
      // label.php - created with Moodle 1.2 development (2003111400)


$string['labeltext'] = 'Đề mục nhãn ';
$string['modulename'] = 'Nhãn';
$string['modulenameplural'] = 'Các nhãn';

?>
