<?php // $Id$ 

$string['blockname'] = 'Các liên kết tới các phần ';
$string['topics'] = 'Các chủ đề';
$string['jumptocurrenttopic'] = 'Chuyển tới chủ đề hiện tại ';
$string['jumptocurrentweek'] = 'Chuyển tới tuần hiện tại';
$string['weeks'] = 'Các tuần';
?>
