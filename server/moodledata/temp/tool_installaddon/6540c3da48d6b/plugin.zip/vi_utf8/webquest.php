<?php // $Id$ 
      // webquest.php - created with Moodle 1.2 development (2003111400)


$string['modulename'] = 'Webquest';
$string['modulenameplural'] = 'Webquests';

?>
