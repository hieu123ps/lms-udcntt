<?PHP // $Id$ 
      // emailprotect.php - created with Moodle 1.9.2+ (Build: 20080827) (2007101522)
      // local modifications from http://localhost/online


$string['filtername'] = 'Bảo vệ thư điện tử';

?>
