<?PHP // $Id$ 
      // block_online_users.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['blockname'] = 'Thành viên trực tuyến';
$string['configtimetosee'] = 'Khoảng thời gian (phút) để xem như thành viên không còn trực tuyến nếu không có hoạt động gì';
$string['online_users:viewlist'] = 'Xem danh sách thành viên trực tuyến';
$string['periodnminutes'] = 'cách đây $a phút';
$string['timetosee'] = 'Thời gian gỡ tên (phút) nếu không có hoạt động gì';

?>
