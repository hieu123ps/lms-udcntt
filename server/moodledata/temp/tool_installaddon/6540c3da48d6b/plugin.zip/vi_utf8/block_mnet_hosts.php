<?PHP // $Id$ 
      // block_mnet_hosts.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['mnet_hosts'] = 'Máy chủ Mạng lưới';
$string['server'] = 'Máy chủ';

?>
