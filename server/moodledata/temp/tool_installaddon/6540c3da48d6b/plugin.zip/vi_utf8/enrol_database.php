<?php // $Id$ 

$string['enrolname'] = 'Có sở dữ liệu bên ngoài';

$string['description'] = 'Bạn có thể sử dụng một cơ sở dữ liệu bên ngoài để điều khiển các khoá truy cập của bạn. Giả sử rằng cơ sở dữ liệu bên ngoài của bạn bao gồm một trường chứa ID cua học, và một trường chứa ID người dùng. Những trường đó được so sánh lại với những trường mà bạn chọn trong các bảng người dùng và cua học nội bộ.';
$string['dbtype'] = 'Loại máy phục vụ cơ sở dữ liệu ';
$string['dbhost'] = 'Tên máy phục vụ cơ sở dữ liệu  ';
$string['dbuser'] = 'Tên đăng nhập để truy cập máy chủ ';
$string['dbpass'] = 'Mật khẩu để truy cập máy chủ';
$string['dbname'] = 'Cở sỏ dữ liệu đặc biệt để sử dụng';
$string['dbtable'] = 'Bảng trong cơ sỏ dữ liệu';
$string['localcoursefield'] = 'Tên của trường trong bảng cua học mà chúng tôi đang sử dụng phù hợp với các mục trong cơ sở dữ liệu từ xa (ví dụ idnumber)';
$string['localuserfield'] = 'Tên của trường trong bảng người dùng cục bộ mà chúng tôi sử dụng  dùng để so khớp người dùng với một bản ghi từ xa (ví dụ idnumber)';
$string['remotecoursefield'] = 'Trường trong cơ sở dữ liệu từ xa chúng tôi mong đợi để tìm ID cua học trong đó';
$string['remoteuserfield'] = 'Trường trong cơ sở dữ liệu từ xa chúng tôi mong đợi để tìm ID người dùng ';

