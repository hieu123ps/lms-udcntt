body,td,tr,li {
  font-family: Arial, Verdana, Helvetica, sans-serif !important;
}
