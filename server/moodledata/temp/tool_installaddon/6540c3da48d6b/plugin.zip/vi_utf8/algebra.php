<?PHP // $Id$ 
      // algebra.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['filtername'] = 'Kí hiệu đại số';

?>
