<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.

$string['auth_manualdescription'] = 'Phương pháp này xoá bỏ bất kỳ cách thức nào của những người sử dụng để tạo các tài khoản của riêng họ. Tất cả các tài khoản phải được tạo bằng tay bởi người quản trị.';
$string['auth_manualtitle'] = 'Chỉ các kê khai bằng tay';