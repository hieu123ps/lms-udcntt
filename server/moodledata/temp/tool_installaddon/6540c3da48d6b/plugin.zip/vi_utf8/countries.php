<?PHP // $Id$ 
      // countries.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['AE'] = 'Các Tiểu Vương quốc Ả Rập Thống nhất';
$string['AU'] = 'Australia';
$string['AX'] = 'Quần đảo Ai Len';
$string['CD'] = 'Cộng hoà Dân chủ Công gô';
$string['CK'] = 'Quần đảo Cook';
$string['CL'] = 'Chi Lê';
$string['CU'] = 'Cu Ba';
$string['CZ'] = 'Cộng Hoà Séc';
$string['DO'] = 'Cộng Hoà Dominican';
$string['FR'] = 'Pháp';
$string['GB'] = 'Vương Quốc Anh';
$string['HK'] = 'Hồng Công';
$string['HM'] = 'Quần đảo Heard và Mc Donald';
$string['HU'] = 'Hung ga ri';
$string['IE'] = 'Ai Len';
$string['IN'] = 'Ấn Độ';
$string['IT'] = 'Ý';
$string['KP'] = 'Triều Tiên';
$string['KR'] = 'Hàn Quốc';
$string['MM'] = 'Miến Điện';
$string['MN'] = 'Mông cổ';
$string['MX'] = 'Mê Hi Cô';
$string['NO'] = 'Na Uy';
$string['PK'] = 'Phi líp pin';
$string['SG'] = 'Sinh ga po';
$string['US'] = 'Mỹ';
$string['VN'] = 'Việt Nam';

?>