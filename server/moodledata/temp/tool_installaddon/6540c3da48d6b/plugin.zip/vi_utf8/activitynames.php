<?PHP // $Id$ 
      // activitynames.php - created with Moodle 1.9.2+ (Build: 20080827) (2007101522)
      // local modifications from http://localhost/online


$string['filtername'] = 'Tự động tạo liên kết cho tên của các hoạt động';

?>
