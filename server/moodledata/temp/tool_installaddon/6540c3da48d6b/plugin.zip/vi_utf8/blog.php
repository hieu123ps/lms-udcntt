<?php  // $Id: blog.php,v 1.2 2006/08/27 08:45:54 koenr Exp $

$string['addnewentry'] = 'Đưa thêm một mục mới';
$string['addotags'] = 'Đưa thêm các thẻ chính thức';
$string['addptags'] = 'Đưa thêm các thẻ tự định nghĩa';
$string['blockmenutitle'] = 'Menu blog';
$string['blogdeleteconfirm'] = 'Xóa blog này?';
$string['blogs'] = 'Các blog';
$string['blogpreferences'] = 'Các thiết lập blog';
$string['entrybody'] = 'Phần nội dung của mục ';
$string['entrybodyonlydesc'] = 'Mô tả mục';
$string['entryerrornotyours'] = 'Mục này không phải của bạn';
$string['entrytitle'] = 'Tiêu đề mục';
$string['entryupdated'] = 'Mục của blog được cập nhật';
$string['noguestpost'] = 'Khách không thể gửi bài viét lên các blog!';
$string['notallowedtoedit'] = 'Bạn không được phép chỉnh sửa mục này';
$string['otags'] = 'Các thẻ chính thức';
$string['pagesize'] = 'Số mục mỗi trang';
$string['ptags'] = 'Các thẻ tự định nghĩa';
$string['publishto'] = 'Xuất bản tới';
$string['publishtonoone'] = 'Của bạn (bản nháp)';
$string['publishtosite'] = 'Bất kỳ ai trên site này';
$string['publishtoworld'] = 'Bất kỳ ai trên thế giới';
$string['settingsupdatederror'] = 'Một lỗi đã xảy ra, các thiết lập cho blog không được cập nhật';
$string['updateentrywithid'] = 'Cập nhật mục';
$string['viewcourseentries'] = 'Xem các mục của khóa học';
$string['viewmyentries'] = 'Xem các mục của tôi';
$string['viewsiteentries'] = 'Xem các mục của site';

?>
