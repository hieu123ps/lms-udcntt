<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.

$string['auth_nonedescription'] = 'Người dùng có thể đăng ký va tạo một tài khoản hợp lệ ngay lập tức, không chứng thực dựa vào một máy chủ ở bên ngoài và không xác nhận qua Email. Cẩn thận sử dụng tuỳ chọn này - suy nghĩ về các vấn đề bảo mật và quản trị điều này có thể là nguyên nhân.';
$string['auth_nonetitle'] = 'Không chứng thực';