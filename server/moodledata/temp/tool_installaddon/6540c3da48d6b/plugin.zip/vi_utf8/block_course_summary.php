<?PHP // $Id$ 
      // block_course_summary.php - created with Moodle 1.9.2+ (Build: 20080813) (2007101521)
      // local modifications from http://hochanh.info/moodle


$string['coursesummary'] = 'Tóm tắt khoá học';
$string['pagedescription'] = 'Phần mô tả khoá học/hệ thống';

?>
