<?php // $Id$ 

$string['enrolname'] = 'Paypal';
$string['description'] = 'Module Paypal cho phép bạn thiết lập trả chi phí các cua học. Nếu chi phí cho bất kỳ cua học nào bằng không, thì khi đó các học viên không được yêu cầu thanh toán đối với mục nhập. Có một chi phí site-wide mà bạn thiết lập ở đây như một mặc dịnh đối với toàn bộ site và tiếp theo bạn có thể thiết lập riêng cho từng cua học. Chi phí cua học quan trọng hơn chi phí site.';
$string['business'] = 'Bản liệt kê Paypal các địa chỉ email của doanh nghiệp của bạn ';
$string['sendpaymentbutton'] = 'Gửi tiền qua Paypal';



?>
