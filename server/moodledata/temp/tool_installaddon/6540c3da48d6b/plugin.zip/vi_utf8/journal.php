<?php // $Id$ 
      // journal.php - created with Moodle 1.2 + (2004032100)


$string['alwaysopen'] = 'Luôn luôn mở ';
$string['blankentry'] = 'Mục để trống ';
$string['daysavailable'] = 'Số ngày có hiệu lực';
$string['editingended'] = 'Soạn thảo vừa mới kết thúc ';
$string['editingends'] = 'Soạn thảo kết thúc';
$string['entries'] = 'Các mục';
$string['feedbackupdated'] = 'Thông tin phản hồi được cập nhật đối với $a mục';
$string['journalmail'] = '$a->teacher vừa gửi một số thông tin phản hồi cho bạn 
journal entry for \'$a->journal\'

Bạn có thể nhìn thấy nó được thêm vào mục nhật ký của bạn:

    $a->url';
$string['journalmailhtml'] = '$a->teacher vừa gửi một số thông tin phản hồi tới mục nhật kí của bạn
 cho \'<i>$a->journal</i>\'<br /><br />
Bạn có thể nhìn thấy nó  được bổ sung vào <a href=\"$a->url\">mục nhật ký</a>.';
$string['journalname'] = 'Tên sổ nhật ký ';
$string['journalquestion'] = 'Nội dung nhật ký';
$string['journalrating1'] = 'Không thoả đáng';
$string['journalrating2'] = 'Thoả đáng';
$string['journalrating3'] = 'Nổi bật';
$string['modulename'] = ' Sổ nhật ký';
$string['modulenameplural'] = 'Sổ nhật ký';
$string['newjournalentries'] = 'Các mục nhật ký mới';
$string['noentry'] = 'Không có mục nào';
$string['noratinggiven'] = 'Không đưa ra phân loại ';
$string['notopenuntil'] = 'Nhật ký này vẫn chưa được mở ';
$string['notstarted'] = 'Bạn chưa bắt đầu nhật ký này ';
$string['overallrating'] = 'Sự phân loại toàn diện ';
$string['rate'] = 'Xếp loại';
$string['saveallfeedback'] = 'Cất tất cả các thông tin phản hồi';
$string['startoredit'] = 'Bắt đầu hoặc soạn thảo mục nhật ký của tôi';
$string['viewallentries'] = 'Xem $a mục nhật ký ';

?>
