<?php

// All of the language strings in this file should also exist in
// auth.php to ensure compatibility in all versions of Moodle.

$string['auth_fccreators'] = 'Danh sách các nhóm mà các thành viên của chúng được cho  phép tạo các cua học mới. Ngăn cách các nhóm bởi dấu \';\'. Các tên phải được viết theo đúng chính tả như trên máy chủ loại nhất. Hệ thống phân biệt dạng chữ .';
$string['auth_fcdescription'] = 'Phương pháp này sử dụng một máy chủ hạng nhất để kiểm tra khi nào một tên đăng nhập và mật khẩu đưa ra hợp lệ.';
$string['auth_fcfppport'] = 'Cổng máy chủ(3333 là phổ biến nhất )';
$string['auth_fchost'] = 'Địa chỉ máy chủ hạng nhất. Sử dụng địa chỉ IP hoặc tên DNS.';
$string['auth_fcpasswd'] = 'Mật khẩu đối với tài khoản ở trên.';
$string['auth_fctitle'] = 'Sử dụng một máy chủ hạng nhất';
$string['auth_fcuserid'] = 'Userid for FirstClass account with privilege \'Subadministrator\' set.';