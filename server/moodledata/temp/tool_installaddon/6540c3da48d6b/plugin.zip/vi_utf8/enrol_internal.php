<?php // $Id$ 

$string['enrolname'] = 'Khoá trong';

$string['description'] = 'Đây là biểu mẫu mặc định của khoá. Có hai cách thức chính mà một học viên có thể được kết nạp trong  một cua học đặc biệt.
<ul>
<li>Giáo viên hoặc quản trị có thể kết nạp họ bằng tay sử dụng kết nối trong danh sách quản trị cua học 
    trong cua học.</li>
<li>Một cua học có thể có một mật khẩu được định nghĩa, giống như một \" Khoá truy cập\". Ai biết khoá này thì   
    có khả năng tự mình tham gia một cua học.</li>
</ul>';

?>
