<?php // $Id$ 
      // quiz.php - created with Moodle 1.2 development (2003111400)
//translators:  You might want to leave the first two items 'as is' in English
$string['modulename'] = 'Hot Potatoes ';
$string['modulenameplural'] = 'Hot Potatoes';
$string['strattemptlabel'] = 'Các thử nghiệm : Điểm số, Ngày tháng (Thời gian có hiệu lực), [Kỷ luật]';
$string['deleteall'] = 'Xoá tất cả';
$string['clearall'] = 'Làm sạch tất cả';
$string['really'] = 'Bạn có thực sự muốn xoá tất cả các kết quả đối với bài thi này ?';

?>
