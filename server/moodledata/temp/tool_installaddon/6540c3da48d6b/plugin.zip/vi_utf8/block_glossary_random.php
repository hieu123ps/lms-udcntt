<?PHP // $Id$ 
      // block_glossary_random.php - created with Moodle 1.9.5+ (Build: 20090812) (2007101550)
      // local modifications from http://vnslearning.com/online


$string['addentry'] = 'Đưa thêm trích dẫn mà bạn yêu thích!';
$string['askaddentry'] = 'Khi thành viên có quyền viết thêm các thuật ngữ mới, hiển thị đường liên kết tới văn bản này';
$string['askinvisible'] = 'Khi thành viên không có quyền viết thêm các thuật ngữ mới, hiển thị văn bản này (không có đường liên kết)';
$string['askviewglossary'] = 'Khi thành viên có quyền xem nhưng không thể thêm thuật ngữ mới, hiển thị đường liên kết tới văn bản này';
$string['blockname'] = 'Thuật ngữ ngẫu nhiên';
$string['intro'] = 'Hãy đảm bảo rằng bạn có ít nhất một bảng thuật ngữ với ít nhất một thuật ngữ để đưa vào khoá học này. Rồi bạn sẽ có thể điều chỉnh các thiết lập tiếp theo';
$string['lastmodified'] = 'Thuật ngữ mới được sửa';
$string['nextone'] = 'Thuật ngữ tiếp theo';
$string['noentriesyet'] = 'Không có thuật ngữ nào trong bảng thuật ngữ đã chọn.';
$string['notyetconfigured'] = 'Hãy nhấn lên biểu tượng chỉnh sửa để cấu hình khối này.';
$string['notyetglossary'] = 'Bạn cần có ít nhất một bảng thuật ngữ để chọn.';
$string['random'] = 'Thuật ngữ ngẫu nhiên';
$string['refresh'] = 'Ngày trước khi chọn một thuật ngữ mới';
$string['select_glossary'] = 'Lấy các thuật ngữ từ bảng thuật ngữ này';
$string['showconcept'] = 'Hiển thị khái niệm (tiêu đề) cho mỗi thuật ngữ';
$string['type'] = 'Cách chọn một thuật ngữ mới';
$string['viewglossary'] = 'Nhiều trích dẫn khác...';
$string['whichfooter'] = 'Bạn có thể cho hiển thị các đường liên kết tới các hành động có liên quan đến khối này. Khối sẽ chỉ hiển thị các đường liên kết tới những hành động được mở cho bảng thuật ngữ trên.';

?>
