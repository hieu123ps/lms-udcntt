<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

defined('MOODLE_INTERNAL') || die;

// namespace theme_edumy;

// $targetRenderer = $CFG->dirroot . "/h5p/classes/output/renderer.php";
// if (file_exists($targetRenderer) {
//   require_once($targetRenderer);
// if (method_exists(\core_h5p\output\renderer::class, 'h5p_alter_styles')) {
//   class theme_edumy_core_h5p_renderer extends \core_h5p\output\renderer {
//     public function h5p_alter_styles(&$scripts, array $libraries, string $embedtype) {
//       // global $PAGE;
//       // $CSS = $PAGE->theme->get_setting('custom_css_h5p');
//       // if (!empty($CSS)) {
//           // $scripts[] = (object) array(
//           //     'path' => 'https://demo.createdbycocoon.com/moodle/edumy/splash/asset/style.css',
//           //     'version' => ''
//           // );
//       // }
//     }
//   }
//   }
// }
